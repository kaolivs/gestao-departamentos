
# Frontend

## Requisitos
- Node 20+
- Angular CLI 17

## Como executar
```bash
npm install
npm start
```
Acesse `http://localhost:4200`.
Edite `src/app/api.service.ts` se precisar alterar a URL da API.
